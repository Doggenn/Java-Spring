package com.adrian.calculadora.service;

public class AritmeticaService {
	
	public Integer suma(Integer num1,Integer num2) {
		return num1 + num2;
	}
	
	public Integer resta(Integer num1,Integer num2) {
		return num1 - num2;
	}
	
	public Integer mult(Integer num1,Integer num2) {
		return num1 * num2;
	}
	
	public Integer div(Integer num1,Integer num2) {
		return num1 / num2;
	}
	
	public Integer rest(Integer num1,Integer num2) {
		return num1 / num2;
	}

}
